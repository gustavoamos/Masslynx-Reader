//-----------------------------------------------------------------------------------------------------
// FILE:			MassLynxSampleList.hpp
// DATE:			Nov 2018
// COPYRIGHT(C):	Waters Corporation
//	
//-----------------------------------------------------------------------------------------------------
#pragma once

#include "MassLynxRawDefs.h"
#include "MassLynxParameters.hpp"
#include "MassLynxRawBase.hpp"

namespace Waters
{
namespace Lib
{
namespace MassLynxRaw
{
	using std::string;

	class MassLynxParameters;

	/**
	*  @brief Builds MassLynx sample list in tab delimited format
	* The sample list can then be submitted using AutoLynx
	*/
	class MassLynxSampleList
	{
	public:
		MassLynxSampleList() : m_pSampleList(NULL)
		{
			m_pCodeHandler = new MassLynxCodeHandler();
			m_pStringHandler = new MassLynxStringHandler();
			createSampleList(&m_pSampleList);
		}

		~MassLynxSampleList()
		{
			delete m_pCodeHandler;
			delete m_pStringHandler;
			destroySampleList(m_pSampleList);
		}

		/**
		* Appends new row to the sample list <br>
		*
		* @param row key value pairs of MassLynxSampleList Items
		*
		*/
		bool AddRow(const MassLynxParameters& row)
		{
			return CheckReturnCode(addSampleListRow(m_pSampleList, row.GetParameters()));
		}

		/**
		*  Returns the sample list table in tab delimited format
		*
		*   @return string
		*/
		string ToString() const
		{
			char* chTable(NULL);
			CheckReturnCode(sampleListToString(m_pSampleList, &chTable));
			return m_pStringHandler->ToString(chTable, false);
		}

		/**
		*  Returns the message associated with the last code
		*
		*   @return string
		*/
		string GetLastMessage() const
		{
			return m_pCodeHandler->GetLastMessage();
		}

		/**
		*  Returns the last code
		*
		*   @return int
		*/
		int GetLastCode() const
		{
			return m_pCodeHandler->GetLastCode();
		}

	private:
		bool CheckReturnCode(const int& nCode) const
		{
			return m_pCodeHandler->CheckReturnCode(nCode, false);
		}

	private:
		CMassLynxSampleList m_pSampleList;
		MassLynxCodeHandler* m_pCodeHandler;
		MassLynxStringHandler* m_pStringHandler;
	};

}   // MassLynxRaw
}   // Lib
}   // Waters