#pragma once
//-----------------------------------------------------------------------------------------------------
// FILE:			MassLynxAcquisition.hpp
// DATE:			October 2021
// COPYRIGHT(C):	Waters Corporation
//	
//-----------------------------------------------------------------------------------------------------
#pragma once

#include "MassLynxRawDefs.h"
#include "MassLynxRawBase.hpp"
#include "MassLynxParameters.hpp"
#include <vector>

namespace Waters
{
namespace Lib
{
namespace MassLynxRaw
{
	using std::string;

	/**
	* Allow sample submission using AutoLynx and access to current sample information
	*
	* Monitoring of the sample lists in the AutoLynx queue
	* Paths to the status files will be initialised if running on a MassLynx system
	* Optionally, the user can set the paths status files
	* 
	* Only available on Windows OS
	*/
	class MassLynxAcquisition
	{
	public:
		MassLynxAcquisition()
		{
			createAcquisition(&_acquisition);
		}

		~MassLynxAcquisition()
		{
			delete _pStringHandler;
			delete _pCodeHandler;
			destroyAcquisition(_acquisition);
		}

		/**
		*   Returns the status of the sample list in the AutoLynx queue
		*
		* 	@param name of the sample list. Note: Not the path
		*   @return AutoLynxStatus
		*/
		AutoLynxStatus GetSampleListStatus(const string& name) const
		{
			AutoLynxStatus status = AutoLynxStatus::UNINITIALISED;
			CheckReturnCode(getSampleListStatus(_acquisition, name.c_str(), &status));
			return status;
		}

		/**
		*   Returns the current AutoLynx settings
		*
		*   @return MassLynxParameters - AutoLynxSettings key / value pairs
		*   @return MassLynxParameters
		*/
		MassLynxParameters AutoLynxSettings()
		{
			MassLynxParameters parameters;
			CheckReturnCode(getAutoLynxSettings(_acquisition, parameters.GetParameters()));
			return parameters;
		}

		/**
		*   Returns the current AutoLynx status
		*
		*   @return AutoLynxStatus
		*/
		AutoLynxStatus GetAutoLynxStatus()
		{
			AutoLynxStatus status = AutoLynxStatus::UNINITIALISED;
			CheckReturnCode(getAutoLynxStatus(_acquisition, &status));
			return status;
		}

		/**
		* Sets the AutoLynx abort flag
		*
		*/
		void AbortAutoLynx()
		{
			CheckReturnCode(abortAutoLynx(_acquisition, true));
		}

		/**
		* Removes the AutoLynx abort flag 
		*
		*/
		void ResumeAutoLynx()
		{
			CheckReturnCode(abortAutoLynx(_acquisition, false));
		}

		/**
		* Set the path to the status ini file
		*
		* @param path to the status ini file
		* 
		*/
		void SetStatusFile(const string& path)
		{
			CheckReturnCode(setStatusIniFile(_acquisition, path.c_str()));
		}

		/**
		* Returns the path to the status ini file
 		* This can be used to monitor the file for updates
		* 
		* @return string
		* 
		*/
		std::string GetStatusFile() const
		{
			MassLynxParameters mlParameters;
			CheckReturnCode(getStatusIniFile(_acquisition, mlParameters.GetParameters()));
			return mlParameters.Get(0);
		}

		/**
		* Returns the current MassLynx status
		* Exception will be thrown on error
		* 
		* @param[out] status containing key / value of MassLynxStatusType
		* @param[out] vector containing the queue
		*
		* @return void
		*/	
		void GetMassLynxStatus(MassLynxParameters& status, std::vector<string>& queue)
		{
			queue.clear();
			MassLynxParameters queueParams;
			CheckReturnCode(getStatus(_acquisition, status.GetParameters(), queueParams.GetParameters()));

			vector<int> keys = queueParams.GetKeys();
			for (int i : keys)
				queue.push_back(queueParams.Get(i));
		}

		/**
		* Returns the current MassLynx status
		* Exception will not be thrown, use GetLastError to retrieve error code
		*
		* @param[out] status containing key / value of MassLynxStatusType
		* @param[out] vector containing the queue
		*
		* @return bool - true if sucessful
		*/
		bool TryGetMassLynxStatus(MassLynxParameters& status, std::vector<string>& queue)
		{
			queue.clear();
			MassLynxParameters queueParams;
			const bool success = CheckReturnCode(getStatus(_acquisition, status.GetParameters(), queueParams.GetParameters()),false);

			vector<int> keys = queueParams.GetKeys();
			for (int i : keys)
				queue.push_back(queueParams.Get(i));

			return success;
		}

		/**
		* Set the path to the MLCurSmp.txt file
		*
		* @param path to the  MLCurSmp.txt file
		*
		*/
		void SetMassLynxInjectionFile(const string& path)
		{
			CheckReturnCode(setMassLynxInjectionFile(_acquisition, path.c_str()));
		}

		/**
		* Returns the path to the MLCurSmp.txt file
		* This can be used to monitor the file for updates
		*
		* @return string
		*
		*/
		std::string GetMassLynxInjectionFile() const
		{
			MassLynxParameters mlParameters;
			CheckReturnCode(getMassLynxInjectionFile(_acquisition, mlParameters.GetParameters()));
			return mlParameters.Get(0);
		}
		
		/**
		* Returns the current MassLynx injection
		* Can be used to get the injection information when running processes from the MassLynx SampleList
		* 
		* Exception will be thrown on error
		*
		* @return status containing key / value of MassLynxSampleListItem
		*/

		MassLynxParameters GetMassLynxInjection()
		{
			MassLynxParameters injection;
			CheckReturnCode(getMassLynxInjection(_acquisition, injection.GetParameters()));
			return injection;
		}

		/**
		* Returns the current MassLynx injection
		* Can be used to get the injection information when running processes from the MassLynx SampleList
		* 
		* Exception will not be thrown, use GetLastError to retrieve error code
		*
		* @param[out] status containing key / value of MassLynxSampleListItem
		*
		* @return bool - true if sucessful
		*/
		bool TryGetMassLynxInjection(MassLynxParameters& injection)
		{
			return CheckReturnCode(getMassLynxInjection(_acquisition, injection.GetParameters()), false);
		}

		/**
		* Returns the last error message
		*/
		string GetLastMessage() const
		{
			return _pCodeHandler->GetLastMessage();
		}

		/**
		* Returns the last error code
		*/
		int GetLastCode() const
		{
			return _pCodeHandler->GetLastCode();
		}

	private:
		bool CheckReturnCode(const int& nCode, const bool& bThrow = true) const
		{
			return _pCodeHandler->CheckReturnCode(nCode, bThrow);
		}

		CMassLynxAcquisition _acquisition = NULL;
		MassLynxCodeHandler* _pCodeHandler = new MassLynxCodeHandler();
		MassLynxStringHandler* _pStringHandler = new MassLynxStringHandler();
	};
}
}
}
