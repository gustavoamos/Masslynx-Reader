//-----------------------------------------------------------------------------------------------------
// FILE:			MassLynxDDAProcessor.h
// DATE:			July 2018
// COPYRIGHT(C):	Waters Corporation
//
//-----------------------------------------------------------------------------------------------------
#pragma once

#include "MassLynxRawBase.hpp"

namespace Waters
{
namespace Lib
{
namespace MassLynxRaw
{
	using std::vector;

	/**
	Processes dda data returning MS1 and MS2 scans
	MS1 scan is the survey scan, MS2 is the associated fragment scan
	*/
	class MassLynxDDAProcessor : public MassLynxBaseProcessor
	{
	public:
		MassLynxDDAProcessor() : MassLynxBaseProcessor(MassLynxBaseType::DDA) {}

		/**
		* Returns the number of DDA scans
		* Exception will not be thrown, use GetLastError to retrieve error code
		* @return true if successfull
		* @param [out] count of scans in the processed DDA data
		*/
		bool TryGetScanCount(int& count) const
		{
			// get the data..
			return CheckReturnCode(ddaGetScanCount(GetProcessor(), &count), false);
		}

		/**
		*  Returns the number of DDA scans
		*  Exception will be thrown on error
		*
		*   @return number of scans
		*/
		int GetScanCount() const
		{
			// get the data..
			int count(0);
			CheckReturnCode(ddaGetScanCount(GetProcessor(), &count), true);
			return count;
		}

		/**
		* Get the scan at the requested index
		* @param whichScan
		* @param [out] parameters
		* @param [out] masses
		* @param [out] intensities
		* @param [out] parameters MassLynxDDAIndexDetail key / value pairs
		* @return true if scan available
		*/
		bool GetScan(const int& whichScan, vector<float>& masses, vector<float>& intensities, MassLynxParameters& parameters) const
		{
			// get the data..
			float* pMasses(NULL); float* pIntensities(NULL); int nSize(0); bool bNext(false);
			bool success = CheckReturnCode(ddaGetScan(GetProcessor(), whichScan, &pMasses, &pIntensities, &nSize, parameters.GetParameters()), false);

			// fill the vector
			ToVector(pMasses, nSize, masses);
			ToVector(pIntensities, nSize, intensities);

			return success;
		}

		/**
		* Get information about the scan
		* @param [out] parameters MassLynxDDAIndexDetail key / value pairs
		* @return true if scan available
		*/
		bool GetScanInfo(const int& whichScan, MassLynxParameters& parameters) const
		{
			// get the data..
			return CheckReturnCode(ddaGetScanInfo(GetProcessor(), whichScan, parameters.GetParameters()), false);
		}

		/**
		Get the next available scan in the processor
		@param [out] masses
		@param [out] intensities
		@param [out] parameters MassLynxDDAIndexDetail key / value pairs
		@return true if scan available
		*/
		bool GetNextScan(vector<float>& masses, vector<float>& intensities, MassLynxParameters& parameters) const
		{
			// get the data..
			float* pMasses(NULL); float* pIntensities(NULL); int nSize(0); bool bNext(false);
			CheckReturnCode(ddaGetNextScan(GetProcessor(), &pMasses, &pIntensities, &nSize, parameters.GetParameters(), &bNext), false);

			// fill the vector
			ToVector(pMasses, nSize, masses);
			ToVector(pIntensities, nSize, intensities);

			return bNext;
		}

		/**
		Reset the next scan counter
		@return void
		*/
		void Reset() const
		{
			// reset the scan iterator
			CheckReturnCode(ddaResetScan(GetProcessor()));
		}

		/**
		*   Set if spectra should be centroided as part of DDAProcessing.
		*
		*   @param  bCentroid	True, spectra is centroided (default: False)
		*   @return this
		*/
		MassLynxDDAProcessor& SetCentroid(const bool& bCentroid)
		{
			MassLynxParameters parameters;
			parameters.Set(DDAParameter::CENTROID, bCentroid);
			return SetParameters(parameters);
		}

		/**
		*   Sets the processing parameters in the DDA processor.
		*	Parameters are supplied in a key value pair in the MassLynxParameter class
		*
		*	Key	Description
		*	DDAProcessingParameter::CENTROID	True is spectra should be centroided (default: False)
		*
		*   @param  ddaProcessingParameters
		*
		*   @return this
		*/
		MassLynxDDAProcessor& SetParameters(const MassLynxParameters& parameters)
		{
			CheckReturnCode(setDDAParameters(GetProcessor(), parameters.GetParameters()));
			return *this;
		}

		/**
		*   Gets the processing parameters set in the DDA processor.
		*
		*   @return MassLynxParameters class
		*/
		MassLynxParameters GetParameters() const
		{
			MassLynxParameters parameters;
			CheckReturnCode(getDDAParameters(GetProcessor(), parameters.GetParameters()));
			return parameters;
		}
	};

	/// \cond
	namespace Extended
	{
		class MassLynxDDAProcessor : public Waters::Lib::MassLynxRaw::MassLynxDDAProcessor
		{
		public:
			MassLynxDDAProcessor() : Waters::Lib::MassLynxRaw::MassLynxDDAProcessor() {}
			/**
			*   Sets the parameters into the DDA processor.
			*	Parameters are supplied in a key value pair in the MassLynxParameter class
			*
			*	Key	Description
			*	DDAParameter::LOWEROFFSET	Lower mass offset
			*	DDAParameter::UPPEROFFSET	Upper mass offset
			*
			*   @param  ddaParameters
			*
			*   @return void
			*/
			MassLynxDDAProcessor& SetQuadIsolationWindowParameters(const MassLynxParameters& ddaParameters)
			{
				CheckReturnCode(setQuadIsolationWindowParameters(GetProcessor(), ddaParameters.GetParameters()));
				return *this;
			}

			/**
			*   Gets the parameters set in the DDA processor.
			*
			*   @return MassLynxParameters class
			*/
			MassLynxParameters GetQuadIsolationWindowParameters() const
			{
				MassLynxParameters parameters;
				CheckReturnCode(getQuadIsolationWindowParameters(GetProcessor(), parameters.GetParameters()));
				return parameters;
			}
		};
	};
	/// \endcond
}
}
}
