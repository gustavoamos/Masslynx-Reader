//-----------------------------------------------------------------------------------------------------
// FILE:			MassLynxLicense.hpp
// DATE:			Feb 2024
// COPYRIGHT(C):	Waters Corporation
//
// COMMENTS:		This header contains the declaration of the MassLynxLicense
//					class.
//-----------------------------------------------------------------------------------------------------
#pragma once

#include <string>
#include "MassLynxParameters.hpp"

namespace Waters
{
namespace Lib
{
namespace MassLynxRaw
{
	class MassLynxLicense
	{
	public:
		/**
		*  Returns information about the license and version of the MassLynx SDK.
		*  The user license key should match the MassLynx SDK version
		*
		*  @param  licenseKey - the user license key
		*
		*  @return MassLynxParameters - LicenseParameter key / value pairs
		*/
		static MassLynxParameters CheckLicense(const std::string& licenseKey)
		{
			MassLynxParameters parameters;
			getLicenseInfo(licenseKey.c_str(), parameters.GetParameters());
			return parameters;
		}
	};
}
}
}
