//-----------------------------------------------------------------------------------------------------
// FILE:			MassLynxScanProcessor.h
// DATE:			July 2018
// COPYRIGHT(C):	Waters Corporation
//
//-----------------------------------------------------------------------------------------------------
#pragma once

#include "MassLynxRawBase.hpp"
#include "MassLynxParameters.hpp"

namespace Waters
{
namespace Lib
{
namespace MassLynxRaw
{
	using std::string;
	using std::vector;
	/**
	* Provides processing for scans
	* 
	* Initially scan must be loaded or combined to produce a scan for subsequent processing
	*/

	class MassLynxScanProcessor : public MassLynxBaseProcessor
	{
	public:
		MassLynxScanProcessor() : MassLynxBaseProcessor(MassLynxBaseType::SCAN) {}

	public:
		/**
		*  Returns the processed scan
		*
		*  @param [out] vector of masses
		*  @param [out] vector of intensities
		*
		*/
		void GetScan(vector<float>& masses, vector<float>& intensities) const
		{
			// get the data..
			float* pMasses(NULL);
			float* pIntensities(NULL);
			int nSize(0);
			CheckReturnCode(getScan(GetProcessor(), &pMasses, &pIntensities, &nSize));

			// fill the vector and deallocate the memory
			ToVector(pMasses, nSize, masses);
			ToVector(pIntensities, nSize, intensities);
		}

		/**
		* Loads single scan into the processor
		*
		* @param  whichFunction requested function
		* @param  whichScan 
		*
		*/
		MassLynxScanProcessor& Load(const int& whichFunction, const int& whichScan)
		{
			CheckReturnCode(combineScan(GetProcessor(), whichFunction, whichScan, whichScan));
			return *this;
		}

		/**
		* Loads single scan into the processor
		*
		* @param  whichFunction requested function
		* @param  whichScan
		* @param  whichDrift
		*
		*/
		MassLynxScanProcessor& Load(int whichFunction, int whichScan, int whichDrift)
		{
			return Combine(whichFunction, whichScan, whichScan, whichDrift, whichDrift);
		}

		/**
		* Combines range of scans
		*
		* @param  whichFunction requested function
		* @param  startScan
		* @param  endScan
		*
		*/
		MassLynxScanProcessor& Combine(const int& whichFunction, const int& startScan, const int& endScan)
		{
			CheckReturnCode(combineScan(GetProcessor(), whichFunction, startScan, endScan));
			return *this;
		}

		/**
		* Combines range of scans
		*
		* @param  whichFunction requested function
		* @param  startScan
		* @param  endScan
		* @param  startDrift
		* @param  endDrift
		*
		*/
		MassLynxScanProcessor& Combine(const int& whichFunction, const int& startScan, const int& endScan, const int& startDrift, const int& endDrift)
		{
			CheckReturnCode(combineDriftScan(GetProcessor(), whichFunction, startScan, endScan, startDrift, endDrift));
			return *this;
		}

		/**
		*   Sets the threshold parameters
		*	Parameters are supplied in a key value pair in the MassLynxParameter class
		*
		*	Key	Description
		*	ThresholdParameter::VALUE			
		*	ThresholdParameter::TYPE	ThresholdType::ABSOLUTE_THRESHOLD or ThresholdType::RELATIVE_THRESHOLD 
		*	
		*/
		MassLynxScanProcessor& SetThresholdParameters(const MassLynxParameters& thresholdParameters)
		{
			CheckReturnCode(setThresholdParameter(GetProcessor(), thresholdParameters.GetParameters()));
			return *this;
		}

		/**
		*   Thresholds the spectrum in the processor using the supplied values 
		*	Parameters are supplied in a key value pair in the MassLynxParameter class
		*
		*   @param  MassLynxParameters ThresholdParameter key / value pairs
		*
		*/
		MassLynxScanProcessor& Threshold(const MassLynxParameters& thresholdParameters)
		{
			SetThresholdParameters(thresholdParameters);
			return Threshold();
		}

		/**
		*   Thresholds the spectrum in the processor using values set in the processor
		*
		*/
		MassLynxScanProcessor& Threshold()
		{
			CheckReturnCode(thresholdScan(GetProcessor()));
			return *this;
		}

		/**
		*   Sets the smooth parameters
		*	Parameters are supplied in a key value pair in the MassLynxParameter class
		*
		*	Key	Description
		*	SmoothParameter::NUMBER
		*   SmoothParameter::WIDTH
		*	SmoothParameter::TYPE	SmoothType::MEAN,  SmoothType::MEDIAN or SmoothType::SAVITZKY_GOLAY
		*
		*/
		MassLynxScanProcessor& SetSmoothParameters(const MassLynxParameters& smoothParameters)
		{
			CheckReturnCode(setSmoothParameter(GetProcessor(), smoothParameters.GetParameters()));
			return *this;
		}

		/**
		*   Returns the smooth parameters set in the processor
		*
		*	@return SmoothParameter key / value pairs
		*
		*/
		MassLynxParameters GetSmoothParameters()
		{
			MassLynxParameters parameters;
			CheckReturnCode(getSmoothParameter(GetProcessor(), parameters.GetParameters()));
			return parameters;
		}

		/**
		*   Smooths the spectrum in the processor using the supplied values
		*	Parameters are supplied in a key value pair in the MassLynxParameter class
		*
		*   @param  MassLynxParameters SmoothParameter key / value pairs
		*
		*/
		MassLynxScanProcessor& Smooth(const MassLynxParameters& smoothParameters)
		{
			SetSmoothParameters(smoothParameters);
			return Smooth();
		}

		/**
		*   Smooths the spectrum in the processor using values set in the processor
		*
		*/
		MassLynxScanProcessor& Smooth()
		{
			CheckReturnCode(smoothScan(GetProcessor()));
			return *this;
		}


		/**
		*   Returns the centroid parameters set in the processor
		*
		*	@return CentroidParameter key / value pairs
		*
		*/
		MassLynxParameters GetCentroidParameters()
		{
			MassLynxParameters parameters;
			CheckReturnCode(getCentroidParameter(GetProcessor(), parameters.GetParameters()));
			return parameters;
		}

		/**
		*   Centroids the spectrum in the processor using values set in the processor
		*
		*/
		MassLynxScanProcessor& Centroid()
		{
			CheckReturnCode(centroidScan(GetProcessor()));
			return *this;
		}
	};

	///  \cond
	namespace Extended
	{
		class MassLynxScanProcessor : public Waters::Lib::MassLynxRaw::MassLynxScanProcessor
		{
		public:
			MassLynxScanProcessor() : Waters::Lib::MassLynxRaw::MassLynxScanProcessor() {}

			MassLynxScanProcessor& SetScan(const vector<float>& masses, const vector<float>& intensities)
			{
				CheckReturnCode(setScan(GetProcessor(), masses.data(), intensities.data(), static_cast<int>(masses.size()), static_cast<int>(intensities.size())));
				return *this;
			}

			MassLynxScanProcessor& SetCentroidParameters(const MassLynxParameters& centroidParameters)
			{
				CheckReturnCode(setCentroidParameter(GetProcessor(), centroidParameters.GetParameters()));
				return *this;
			}

			MassLynxScanProcessor& Centroid(const MassLynxParameters& centroidParameters)
			{
			    SetCentroidParameters(centroidParameters);
				return Centroid();
			}

			MassLynxScanProcessor& Centroid()
			{
				Waters::Lib::MassLynxRaw::MassLynxScanProcessor::Centroid();
				return *this;
			}
		};
	}
	///  \endcond
}   // MassLynxRaw
}   // Lib
}   // Waters



