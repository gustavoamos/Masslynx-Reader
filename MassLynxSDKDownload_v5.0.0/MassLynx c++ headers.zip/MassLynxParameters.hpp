//-----------------------------------------------------------------------------------------------------
// FILE:			MassLynxParameters.hpp
// DATE:			July 2018
// COPYRIGHT(C):	Waters Corporation
//	
//-----------------------------------------------------------------------------------------------------
#pragma once

#include "MassLynxRawDefs.h"
#include "MassLynxRawBase.hpp"

namespace Waters
{
namespace Lib
{
namespace MassLynxRaw
{
	using std::string;

	/**
	*  @brief Helper class to build parameter settings
	*/
	class MassLynxParameters
	{
	public:
		MassLynxParameters() : _parameters(NULL)
		{
			_stringHandler = new MassLynxStringHandler();
			createParameters(&_parameters);
		}

		MassLynxParameters(const MassLynxParameters& mlParams) : _parameters(NULL)
		{
			_stringHandler = new MassLynxStringHandler();
			createParametersFromParameters(mlParams.GetParameters(), &_parameters);
		}

		~MassLynxParameters()
		{
			delete _stringHandler;
			destroyParameters(_parameters);
		}

		template< typename T>
		MassLynxParameters& Set(const MassLynxScanItem& key, const T& value)
		{
			return Set((int)key, value);
		}

		template< typename T>
		MassLynxParameters& Set(const MassLynxHeaderItem& key, const T& value)
		{
			return Set((int)key, value);
		}

		template< typename T>
		MassLynxParameters& Set(const MassLynxSampleListItem& key, const T& value)
		{
			return Set((int)key, value);
		}

		template< typename T>
		MassLynxParameters& Set(const MassLynxBatchItem& key, const T& value)
		{
			return Set((int)key, value);
		}

		template< typename T>
		MassLynxParameters& Set(const LockMassParameter& key, const T& value)
		{
			return Set((int)key, value);
		}

		MassLynxParameters& Set(const SmoothParameter& key, const int& value)
		{
			return Set((int)key, value);
		}

		MassLynxParameters& Set(const SmoothParameter& key, const SmoothType& value)
		{
			return Set((int)key, (int)value);
		}

		template< typename T>
		MassLynxParameters& Set(const CentroidParameter& key, const T& value)
		{
			return Set((int)key, value);
		}

		template< typename T>
		MassLynxParameters& Set(const ThresholdParameter& key, const T& value)
		{
			return Set((int)key, (int)value);
		}

		// Function parameters for raw writer
		template< typename T>
		MassLynxParameters& Set(const FunctionDefinition& key, const T& value)
		{
			return Set((int)key, (int)value);
		}

		MassLynxParameters& Set(const FunctionDefinition& key, const float& value)
		{
			return Set((int)key, value);
		}

		MassLynxParameters& Set(const FunctionDefinition& key, const double& value)
		{
			return Set((int)key, value);
		}

		MassLynxParameters& Set(const MassLynxDDAIndexDetail& key, const double& value)
		{
			return Set((int)key, value);
		}

		MassLynxParameters& Set(const MassLynxDDAIndexDetail& key, const float& value)
		{
			return Set((int)key, value);
		}

		MassLynxParameters& Set(const MassLynxDDAIndexDetail& key, const int& value)
		{
			return Set((int)key, value);
		}

		MassLynxParameters& Set(const MassLynxDDAIndexDetail& key, const bool& value)
		{
			return Set((int)key, value);
		}

		MassLynxParameters& Set(const MassLynxDDAIndexDetail& key, const MassLynxScanType& value)
		{
			return Set((int)key, (int)value);
		}

		MassLynxParameters& Set(const DDAIsolationWindowParameter& key, const float& value)
		{
			return Set((int)key, value);
		}

		MassLynxParameters& Set(const DDAParameter& key, const bool& value)
		{
			return Set((int)key, value);
		}

		string Get(const MassLynxHeaderItem& key) const
		{
			return Get((int)key);
		}

		string Get(const MassLynxScanItem& key) const
		{
			return Get((int)key);
		}

		string Get(const SmoothParameter& key) const
		{
			return Get((int)key);
		}

		string Get(const CentroidParameter& key) const
		{
			return Get((int)key);
		}

		string Get(const LockMassParameter& key) const
		{
			return Get((int)key);
		}

		string Get(const AcquisitionParameter& key) const
		{
			return Get((int)key);
		}

		string Get(const MassLynxSampleListItem& key) const
		{
			return Get((int)key);
		}

		string Get(const MassLynxBatchItem& key) const
		{
			return Get((int)key);
		}				

		string Get(const MassLynxDDAIndexDetail& key) const
		{
			return Get((int)key);
		}

		string Get(const DDAIsolationWindowParameter& key) const
		{
			return Get((int)key);
		}

		string Get(const DDAParameter& key) const
		{
			return Get((int)key);
		}

		string Get(const LicenseParameter& key) const
		{
			return Get((int)key);
		}

		vector<int> GetKeys() const
		{
			int* pKeys(NULL);
			int size(0);
			getParameterKeys(_parameters, &pKeys, &size);
			return vector<int>(pKeys, pKeys + size);
		}

		string Get(const int& key) const
		{
			char* pValue(NULL);
			getParameterValue(_parameters, key, &pValue);
			return _stringHandler->ToString(pValue, false);
		}

		/// \cond
		// Overload =
		MassLynxParameters operator=(const MassLynxParameters& rhs)
		{
			destroyParameters(_parameters);
			createParametersFromParameters(rhs.GetParameters(), &_parameters);
			return *this;
		}

		CMassLynxParameters GetParameters() const { return _parameters; }
		/// \endcond

	private:
		MassLynxParameters& Set(const int& key, const char* value)
		{
			setParameterValue(_parameters, key, value);
			return *this;
		}

		MassLynxParameters& Set(const int& key, const string& value)
		{
			Set(key, value.c_str());
			return *this;
		}

		MassLynxParameters& Set(const int& key, const float& value)
		{
			Set(key, std::to_string(value));
			return *this;
		}

		MassLynxParameters& Set(const int& key, const double& value)
		{
			Set(key, std::to_string(value));
			return *this;
		}

		MassLynxParameters& Set(const int& key, const int& value)
		{
			Set(key, std::to_string(value));
			return *this;
		}

		MassLynxParameters& Set(const int& key, const bool& value)
		{
			Set(key, std::to_string(value));
			return *this;
		}

		MassLynxParameters& Set(const int& key, const SmoothType& value)
		{
			Set(key, (int)value);
			return *this;
		}

	private:
		CMassLynxParameters _parameters;
		MassLynxStringHandler* _stringHandler;
	};

}   // MassLynxRaw
}   // Lib
}   // Waters