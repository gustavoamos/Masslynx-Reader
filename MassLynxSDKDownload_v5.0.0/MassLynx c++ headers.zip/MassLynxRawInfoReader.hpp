//-----------------------------------------------------------------------------------------------------
// FILE:			MassLynxRawInfo.hpp
// DATE:			Feb 2021
// COPYRIGHT(C):	Waters Corporation
//
// COMMENTS:		This header contains the declaration of the MassLynxRawInfo
//					class.
//-----------------------------------------------------------------------------------------------------
#pragma once

#include "MassLynxRawBase.hpp"
#include "MassLynxParameters.hpp"
#include <cmath>

namespace Waters
{
namespace Lib
{
namespace MassLynxRaw
{
	using std::string;
	using std::vector;

	/**
 	*  @brief 
	* Allows access to raw scan data and statistics
	*
	* If an error is encountered then an exception will be throw, see exception codes and messages.
	*/


	class MassLynxRawInfo : public MassLynxBaseReader
	{
	public:
		MassLynxRawInfo(const string & strFullPath, const string& userLicense) : MassLynxBaseReader(strFullPath, MassLynxBaseType::INFO, userLicense) {}
		MassLynxRawInfo(const MassLynxBaseReader& rawReader) : MassLynxBaseReader(rawReader, MassLynxBaseType::INFO) {}
		MassLynxRawInfo(const MassLynxRawInfo& rawReader) : MassLynxBaseReader(rawReader, MassLynxBaseType::INFO) {}

		/**
		*  Returns the number of ms functions in the Raw data.
		*
		*   @return number of functions
		*/
		int GetFunctionCount() const
		{
			unsigned int nFunction(0);
			CheckReturnCode(getFunctionCount(GetRawReader(), &nFunction));
			return nFunction;
		}

		/**
		*  Returns the description of the requested function type.
		*
		*   @param  functionType - requested MassLynxFunctionType
		*
		*   @return function type description
		*/
		string GetFunctionTypeString(const MassLynxFunctionType& functionType) const
		{
			char* chFunctionType(NULL);
			CheckReturnCode(getFunctionTypeString(GetRawReader(), functionType, &chFunctionType));
			return ToString(chFunctionType);
		}

		/**
		*   Returns the AcquisitionParameter key with the value from the raw data acquisition.
		* 
		*	Different parameters will be returned based on the acquisition type
		* 
		*   @return MassLynxParameters - AcquisitionParameter key / value pairs
		*/
		MassLynxParameters GetAcquisitionInfo() const
		{
			MassLynxParameters parameters;
			CheckReturnCode(getAcquisitionInfo(GetRawReader(), parameters.GetParameters()));
			return parameters;
		}

		/**
		*  Returns the requested function type.
		*
		*   @param  whichFunction requested function
		*
		*   @return function type
		*/
		MassLynxFunctionType GetFunctionType(const int& whichFunction) const
		{
			MassLynxFunctionType functionType(MassLynxFunctionType::UNINITIALISED);
			CheckReturnCode(getFunctionType(GetRawReader(), whichFunction, &functionType));
			return functionType;
		}

		/**
		*  Returns the requested ion mode
		*
		*   @param  whichFunction requested function
		*
		*   @return ion mode
		*/
		MassLynxIonMode GetIonMode(const int& whichFunction) const
		{
			MassLynxIonMode ionMode(MassLynxIonMode::UNINITIALISED);
			CheckReturnCode(getIonMode(GetRawReader(), whichFunction, &ionMode));
			return ionMode;
		}

		/**
		*  Returns the requested ion mode description.
		*
		*   @param  ionMode MassLynxIonMode
		*
		*   @return ion mode description
		*/
		string GetIonModeString(const MassLynxIonMode& ionMode) const
		{
			char* chIonMode(NULL);
			CheckReturnCode(getIonModeString(GetRawReader(), ionMode, &chIonMode));
			return ToString(chIonMode);
		}

		/**
		*  Returns the retention time of a scan.
		*
		*   @param  whichFunction requested function
		*   @param  whichScan requested scan
		*
		*   @return retention time
		*/
		float GetRetentionTime(const int& whichFunction, const int& whichScan) const
		{
			float fRT(0.0f);
			CheckReturnCode(getRetentionTime(GetRawReader(), whichFunction, whichScan, &fRT));
			return fRT;
		}

		/**
		*  Returns the drift time of a scan.
		*
		*   @param  whichDrift requested scan
		*
		*   @return retention time
		*/
		float GetDriftTime(const int& whichDrift) const
		{
			float fDT(0.0f);
			CheckReturnCode(getDriftTime(GetRawReader(), whichDrift, &fDT));
			return fDT;
		}

		/**
		*   Returns the nearest indeces based on the start and end time
		* 
		*   Exception will not be thrown, use GetLastError to retrieve error code
		*
		*   @param  whichFunction requested function
		*   @param  startDT requested start drift time
		*   @param  endDT requested end drift time
		*   @param [out] startDrift index
		*   @param [out] endDrift index
		*
		*   @return true if successful
		*/
		bool TryGetDriftRange(int whichFunction, float startDT, float endDT, int& startDrift, int& endDrift)
		{
			return CheckReturnCode(getDriftRangeFromTimeRange(GetRawReader(), whichFunction, startDT, endDT, startDrift, endDrift), false);
		}

		/**
		*  Returns the Drift Time calcuated using the drift time calibration
		* 
		*  Collisional Cross Section calibration must be present
		*  Exception will be thrown on error
		*
		*   @param  ccs requested collisional cross section
		*   @param  neutralMass
		*   @param  charge
		*
		*   @return DriftTime
		*/
		float GetDriftTime(const float& ccs, const float& neutralMass, const int& charge) const
		{
			float dt(nanf(""));
			CheckReturnCode(getDriftTime_CCS(GetRawReader(), ccs, neutralMass, charge, &dt));
			return dt;
		}

		/**
		* Returns the Drift Time calcuated using the drift time calibration
		* 
		* Collisional Cross Section calibration must be present
		* Exception will not be thrown, use GetLastError to retrieve error code
		*
		*  @param  ccs requested collisional cross section
		*  @param  mass
		*  @param  charge
		*  @param [out] dt
		*
		*  @return true if successful

		*/
		bool TryGetDriftTime(const float& ccs, const float& mass, const int& charge, float & dt) const
		{
			return CheckReturnCode(getDriftTime_CCS(GetRawReader(), ccs, mass, charge, &dt), false);
		}

		/**
		*  Returns the CollisionalCrossSection
		* 
		*  Collisional Cross Section calibration must be present
		*  Exception will be thrown on error
		*
		*   @param  driftTime requested drift time
		*   @param  mass
		*   @param  charge
		*
		*   @return CollisionalCrossSection
		*/
		float GetCollisionalCrossSection(const float& driftTime, const float& mass, const int& charge) const
		{
			float fCCS(nanf(""));
			CheckReturnCode(getCollisionalCrossSection(GetRawReader(), driftTime, mass, charge, &fCCS));
			return fCCS;
		}

		/**
		*  Returns the CollisionalCrossSection
		* 
		*  Collisional Cross Section calibration must be present
		*  Exception will not be thrown, use GetLastError to retrieve error code
		*
		*  @param  driftTime requested drift time
		*  @param  mass
		*  @param  charge
		*  @param [out] CCS collisional cross section
		*
		*  @return true if successful
		*/

		bool TryGetCollisionalCrossSection(const float& driftTime, const float& mass, const int& charge, float& CCS) const
		{
			return CheckReturnCode(getCollisionalCrossSection(GetRawReader(), driftTime, mass, charge, &CCS), false);
		}

		/**
		*  Returns the acquisition mass range of the requested function.
		*
		*   @param  whichFunction requested function
		*   @param [out] startMass start mass of the function
		*   @param [out] endMass end mass of the function
		*
		*   @return void
		*/
		void GetAcquisitionMassRange(const int& whichFunction, float& startMass, float& endMass) const
		{
			CheckReturnCode(getAcquisitionMassRange(GetRawReader(), whichFunction, 0, &startMass, &endMass));
		}

		/**
		*  Returns the acquisition mass range of the requested function.
		*
		*   @param  whichFunction requested function
		*   @param  whichMRM requested mrm transition
		*   @param [out] startMass start mass of the function
		*   @param [out] endMass end mass of the function
		*
		*   @return void
		*/
		void GetAcquisitionMassRange(const int& whichFunction, const int& whichMRM, float& startMass, float& endMass) const
		{
			CheckReturnCode(getAcquisitionMassRange(GetRawReader(), whichFunction, whichMRM, &startMass, &endMass));
		}

		/**
		*  Returns the acquisition time range of the requested function.
		*
		*   @param  whichFunction requested function
		*   @param [out] startTime start time of the function
		*   @param [out] endTime end time of the function
		*
		*   @return void
		*/
		void GetAcquisitionTimeRange(const int& whichFunction, float& startTime, float& endTime) const
		{
			CheckReturnCode(getAcquisitionTimeRange(GetRawReader(), whichFunction, &startTime, &endTime));
		}

		/**
		*   Returns the number of scans in the requested function 
		*
		*   @param  whichFunction requested function
		*
		*   @return number of scans
		*/
		int GetScansInFunction(const int& whichFunction) const
		{
			unsigned int nScans(0);
			CheckReturnCode(getScanCount(GetRawReader(), whichFunction, &nScans));
			return nScans;
		}

		/**
		*  Returns the number of scans in the requested function
		* 
		*  Exception will not be thrown, use GetLastError to retrieve error code
		*
		*  @param  whichFunction requested function
		*  @param [out] number of scans
		*
		*  @return true if successful
		*/

		bool TryGetScansInFunction(const int& whichFunction, unsigned int& nScans) const
		{
			return CheckReturnCode(getScanCount(GetRawReader(), whichFunction, &nScans), false);
		}

		/**
		*   Returns the number of drift scans in the requested function
		*
		*   @param  whichFunction requested function
		*
		*   @return number of scans
		*/
		int GetDriftScanCount(const int& whichFunction) const
		{
			unsigned int nScans(0);
			CheckReturnCode(getDriftScanCount(GetRawReader(), whichFunction, &nScans));
			return nScans;
		}

		/**
		*  Returns the number of MRM transitions in the requested function
		* 
		*  Function must be of type MRM
		*  Exception will be thrown on error
		*
		*  @param  whichFunction requested function
		*
		*  @return nMRMs number of MRM transitions
		*/
		int GetMRMCount(const int& whichFunction) const
		{
			int nMRMs(0);
			CheckReturnCode(getMRMCount(GetRawReader(), whichFunction, &nMRMs));
			return nMRMs;
		}

		/**
		*  Returns the number of MRM transitions in the requested function
		* 
		*  Exception will not be thrown, use GetLastError to retrieve error code
		*
		*
		*  @param  whichFunction requested function
		*  @param [out] nMRMs number of MRM transitions
		*
		*  @return true if successful
		*/
		bool TryGetMRMCount(const int& whichFunction, int& nMRMs) const
		{
			return CheckReturnCode(getMRMCount(GetRawReader(), whichFunction, &nMRMs), false);
		}
		
		/**
		*   Returns the type of data in the requested function
		* 
		*   Exception will be thrown if the function has no scans
		*
		*   @param  whichFunction requested function
		*
		*   @return true if data is continuum
		*/
		bool IsContinuum(const int& whichFunction) const
		{
			bool bContinuum;
			CheckReturnCode(isContinuum(GetRawReader(), whichFunction, bContinuum));
			return bContinuum;
		}

		/**
		*  Returns the type of data in the requested function
		* 
		*  Exception will not be thrown, use GetLastError to retrieve error code
		*
		*  @param  whichFunction requested function
		*  @param [out] continuum
		*
		*  @return true if successful
		*/
		bool TryIsContinuum(const int& whichFunction, bool& continuum) const
		{
			return CheckReturnCode(isContinuum(GetRawReader(), whichFunction, continuum), false);
		}

		/**
		*   Returns the nearest indeces based on the start and end time
		* 
		*   Exception will not be thrown, use GetLastError to retrieve error code
		*
		*   @param  whichFunction requested function
		*   @param  startRT requested start retention time 
		*   @param  endRT requested end retention time 
		*   @param [out] startScan index
		*   @param [out] endScan index
		* 
 		*  @return true if successful
		*/
		bool TryGetScanRange(int whichFunction, float startRT, float endRT, int& startScan, int& endScan)
		{
			return CheckReturnCode(getScanRangeFromTimeRange(GetRawReader(), whichFunction, startRT, endRT, startScan, endScan), false);
		}

		/**
		*   Returns the key / value of the available scan items
		*
		*   @param  whichFunction requested function
		*
		*   @return MassLynxParameters - MassLynxScanItem key / value pairs
		*/
		MassLynxParameters GetScanItems(const int& whichFunction) const
		{
			MassLynxParameters parameters;
			CheckReturnCode(getScanItemsInFunction(GetRawReader(), whichFunction, parameters.GetParameters()));
			return parameters;
		}

		/**
		*  Returns the scan item value for the requested function and scan.
		*
		*   @param  whichFunction requested function
		*   @param  whichScan requested scan
		*	@param  whichItem requested item
		*
		*   @return string scan item value
		*/
		string GetScanItemValue(const int& whichFunction, const int& whichScan, const MassLynxScanItem& whichItem) const
		{
			MassLynxParameters parameters;
			CheckReturnCode(getScanItemValue(GetRawReader(), whichFunction, whichScan, &whichItem, 1, parameters.GetParameters()));
			return parameters.Get(whichItem);
		}


		/**
		*  Returns the  key / value  item for the requested function and scan.
		*
		*   @param  whichFunction requested function
		*   @param  whichScan requested scan
		*	@param  whichItems requested items
		*
		*   @return MassLynxParameters - MassLynxScanItem key / value pairs
		*/
		MassLynxParameters GetScanItemValue(const int& whichFunction, const int& whichScan, const vector<MassLynxScanItem>& whichItems) const
		{
			MassLynxParameters parameters;
			CheckReturnCode(getScanItemValue(GetRawReader(), whichFunction, whichScan, &whichItems[0], static_cast<int>(whichItems.size()), parameters.GetParameters()));
			return parameters;
		}

		/**
		*  Returns the name  key / value for the requested items.
		*
		*	@param  whichItems requested items
		*
		*   @return MassLynxParameters - MassLynxScanItem key / value pairs
		*/
		MassLynxParameters GetScanItemName(const vector<MassLynxScanItem>& whichItems) const
		{
			MassLynxParameters parameters;
			CheckReturnCode(getScanItemName(GetRawReader(), &whichItems[0], static_cast<int>(whichItems.size()), parameters.GetParameters()));
			return parameters;
		}
		
		/**
		*  Returns the name for the requested item.
		*
		*	@param  whichItems requested items
		*
		*   @return string item name
		*/
		string GetScanItemName(const MassLynxScanItem& whichItem) const
		{
			MassLynxParameters parameters;
			CheckReturnCode(getScanItemName(GetRawReader(), &whichItem, 1, parameters.GetParameters()));
			return parameters.Get(whichItem);
		}


		/**
		*   Returns the key/value of the requested header items
		*
		*   @param  vector<MassLynxHeaderItem> vector of requested items
		*
		*   @return MassLynxParameters - MassLynxHeaderItem key / value pairs
		*/
		MassLynxParameters GetHeaderItemValue(const vector<MassLynxHeaderItem>& whichItems) const
		{
			MassLynxParameters parameters;
			CheckReturnCode(getHeaderItemValue(GetRawReader(), &whichItems[0], static_cast<int>(whichItems.size()), parameters.GetParameters()));
			return parameters;
		}

		/**
		*   Returns the value of the requested header item
		*
		*   @param  whichItem enum of requested item
		*
		*   @return string
		*/
		string GetHeaderItemValue(const MassLynxHeaderItem& whichItem) const
		{
			MassLynxParameters parameters;
			CheckReturnCode(getHeaderItemValue(GetRawReader(), &whichItem, 1, parameters.GetParameters()));
			return parameters.Get(whichItem);
		}

		/**
		*   Determines if the raw data has post acquisition lock mass correction applied.
		*
		*   @return false if post acqustion lock mass correction is not applied.
		*/
		bool IsLockMassCorrected() const
		{
			bool bCorrected;
			CheckReturnCode(isLockMassCorrected(GetRawReader(), &bCorrected));
			return bCorrected;
		}

		/**
		*   Determines if post acquisition lock mass correction can be applied.
		* 
		*   Post acquistion lock mass correction can be applied to data which contains
		*   a lock mass channel and has not been lock mass corrected during acquisition or
		*   to calcuate precursor masses for DDA data
		*
		*   @return false if the raw data can not be lock mass corrected.
		*/
		bool CanLockMassCorrect() const
		{
			bool bCanCorrect;
			CheckReturnCode(canLockMassCorrect(GetRawReader(), &bCanCorrect));
			return bCanCorrect;
		}

		/**
		*   Returns the lock mass channel number
		* 
		*   Exception will not be thrown, use GetLastError to retrieve error code
		* 
		*   @param [out] lock mass channel number
		*
		*   @return false if the lock mass channel is not present
		*/
		bool TryGetLockMassFunction( int& whichChannel) const
		{
			bool hasLockmass;
			CheckReturnCode(getLockMassFunction(GetRawReader(), &hasLockmass, &whichChannel), false);
			return hasLockmass;
		}
	};

	/// \cond
	namespace Extended
	{
		class MassLynxRawInfo : public Waters::Lib::MassLynxRaw::MassLynxRawInfo
		{
		public:

			MassLynxRawInfo(const string& strFullPath, const string& userLicense) : Waters::Lib::MassLynxRaw::MassLynxRawInfo(strFullPath, userLicense) {}
			MassLynxRawInfo(const MassLynxRawInfo& massLynxInfo) : Waters::Lib::MassLynxRaw::MassLynxRawInfo(massLynxInfo) {}
			MassLynxRawInfo(const MassLynxBaseReader& massLynxRawReader) : Waters::Lib::MassLynxRaw::MassLynxRawInfo(massLynxRawReader) {}

			/**
			*  Returns the index range base on the precursor mass and tolerance.
			* 
			*  Sonar calibration must be present
			*  Use GetLastCode or GetLastMessage to retrieve error code information
			*
			*   @param  whichFunction requested function
			*   @param  preCursorMass requested precursor mass
			*   @param  preCursorTolerance requested precursor tolerance in mass units
			*   @param [out] startIndex, index assoctated with the start mass ( preCursorMass - preCursorTolerance )
			*   @param [out] endIndex, index assoctated with the end mass ( preCursorMass + preCursorTolerance )
			*
			*   @return true if successful
			*/
			bool GetSonarRange(const int& whichFunction, const float& preCursorMass, const float& preCursorTolerance, int& startIndex, int& endIndex) const
			{
				return CheckReturnCode(getIndexRange(GetRawReader(), whichFunction, preCursorMass, preCursorTolerance * 2, &startIndex, &endIndex), false);
			}

			/**
			*  Returns the precursor mass associated with the index value
			* 
			*  Sonar calibration must be present
			*  Use GetLastCode or GetLastMessage to retrieve error code information
			*
			*  @param  whichFunction requested function
			*  @param  whichIndex requested index
			*  
			*  @param [out] mass
			*
			*  @return true if successful
			*/
			bool TryGetPrecursorMass(const int& whichFunction, const int& whichIndex, float& mass)
			{
				return CheckReturnCode(getPrecursorMass(GetRawReader(), whichFunction, whichIndex, &mass), false);
			}

			/**
			*  Returns the precursor mass associated with the index value
			* 
			*  Sonar calibration must be present
			*  Exception will be thrown on error
			*
			*  @param  whichFunction requested function
			*  @param  whichIndex requested index
			*
			*  @return mass
			*/
			float GetPrecursorMass(const int& whichFunction, const int& whichIndex )
			{
				float mass(nanf(""));
				CheckReturnCode(getPrecursorMass(GetRawReader(), whichFunction, whichIndex, &mass));
				return mass;
			}

			/**
			*  Returns the precursor mass range for the requested index
			* 
			*  Sonar calibration must be present
			*  Use GetLastCode or GetLastMessage to retrieve error code information
			*
			*  @param  whichFunction requested function
	 		*  @param  whichIndex requested index
			*
			*  @param [out] startMass
			*  @param [out] endMass
			*
			*  @return true if successful
			*/
			bool GetPrecursorMassRange(const int& whichFunction, const int& whichIndex, float& startMass, float& endMass)
			{
				return CheckReturnCode(getIndexPrecursorMassRange(GetRawReader(), whichFunction, whichIndex, &startMass, &endMass), false);
			}

			/**
			*  Returns the precursor mass range for the requested function
			* 
			*  Sonar calibration must be present
			*  Use GetLastCode or GetLastMessage to retrieve error code information
			*
			*  @param  whichFunction requested function
			* 
			*  @param [out] startMass
			*  @param [out] endMass
			*
			*  @return true if successful
			*/
			bool GetPrecursorMassRange(const int& whichFunction, float& startMass, float& endMass)
			{
				return CheckReturnCode(getFunctionPrecursorMassRange(GetRawReader(), whichFunction, &startMass, &endMass), false);
			}
		};
	}

	/// \endcond
}
}
}

