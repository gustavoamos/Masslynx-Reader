//-----------------------------------------------------------------------------------------------------
// FILE:			MassLynxRawScanReader.h
// DATE:			Nov 2018
// COPYRIGHT(C):	Waters Corporation
//
//-----------------------------------------------------------------------------------------------------
#pragma once

#include "MassLynxRawBase.hpp"

namespace Waters
{
namespace Lib
{
namespace MassLynxRaw
{
	using std::vector;

	class MassLynxRawScanReader : public MassLynxBaseReader
	{
	public:
		MassLynxRawScanReader(const string & strFullPath, const string& userLicense) : MassLynxBaseReader(strFullPath, MassLynxBaseType::SCAN, userLicense) {}
		MassLynxRawScanReader(const MassLynxRawScanReader& massLynxScanReader) : MassLynxBaseReader(massLynxScanReader, MassLynxBaseType::SCAN) {}
		MassLynxRawScanReader(const MassLynxBaseReader& massLynxRawReader) : MassLynxBaseReader(massLynxRawReader, MassLynxBaseType::SCAN) {}

		/**
		*  Reads the masses and intensities for the requested function and scan
		*
		*   @param  whichFunction requested function
		*   @param  whichScan requested scan
		*   @param [out] vector of masses
		*   @param [out] vector of intensities
		*
		*   @return void
		*/
		void ReadScan(const int& whichFunction, const int& whichScan, vector<float> & masses, vector<float> & intensities)
		{
			// get the data..
			float* pMasses(NULL); float* pIntensities(NULL); int nSize(0);
			CheckReturnCode(readScan(GetRawReader(), whichFunction, whichScan, &pMasses, &pIntensities, &nSize));

			// fill the vector
			ToVector(pMasses, nSize, masses);
			ToVector(pIntensities, nSize, intensities);
		}

		/**
		*  Reads the masses, intensities and flags for the requested function and scan
		*
		*   @param  whichFunction requested function
		*   @param  whichScan requested scan
		*   @param [out] vector of masses
		*   @param [out] vector of intensities
		*   @param [out] vector of flags
		*
		*   @return void
		*/
		void ReadScan(const int& whichFunction, const int& whichScan, vector<float> & masses, vector<float> & intensities, vector<char> & flags)
		{
			// get the data..
			float* pMasses(NULL); float* pIntensities(NULL); char* pFlags(NULL); int nSize(0);
			CheckReturnCode(readScanFlags(GetRawReader(), whichFunction, whichScan, &pMasses, &pIntensities, &pFlags, &nSize));

			// fill the vector
			ToVector(pMasses, nSize, masses);
			ToVector(pIntensities, nSize, intensities);
			ToVector(pFlags, nSize, flags);
		}

		/**
		*  Reads the masses, intensities and product masses for the requested function and scan
		*
		*   @param  whichFunction requested function
		*   @param  whichScan requested scan
		*   @param [out] vector of masses
		*   @param [out] vector of intensities
		*   @param [out] vector of productMasses
		*
		*   @return void
		*/
		void ReadScan(const int& whichFunction, const int& whichScan, vector<float> & masses, vector<float> & intensities, vector<float> & productMasses)
		{
			// get the data..
			float* pMasses(NULL); float* pIntensities(NULL); float* pProductMasses(NULL); int nSize(0); int nProductSize(0);
			CheckReturnCode(readProductScan(GetRawReader(), whichFunction, whichScan, &pMasses, &pIntensities, &pProductMasses, &nSize, &nProductSize));

			// fill the vector
			ToVector(pMasses, nSize, masses);
			ToVector(pIntensities, nSize, intensities);
			ToVector(pProductMasses, nProductSize, productMasses);
		}

		/**
		*  Reads the masses and intensities for the requested function, scan and drift
		*
		*   @param  whichFunction requested function
		*   @param  nWhichScan requested scan
		*   @param  nWhichDrift requested drift
		*   @param [out] vector of masses
		*   @param [out] vector of intensities
		*
		*   @return void
		*/
		void ReadScan(const int& whichFunction, const int& nWhichScan, const int& nWhichDrift, vector<float> & masses, vector<float> & intensities)
		{
			// get the data..
			float* pMasses(NULL); float* pIntensities(NULL); int nSize(0);
			CheckReturnCode(readDriftScan(GetRawReader(), whichFunction, nWhichScan, nWhichDrift, &pMasses, &pIntensities, &nSize));

			// fill the vector
			ToVector(pMasses, nSize, masses);
			ToVector(pIntensities, nSize, intensities);
		}
	};

	/// \cond
	namespace Extended
	{
		class MassLynxRawScanReader : public Waters::Lib::MassLynxRaw::MassLynxRawScanReader
		{
		public:
			using Waters::Lib::MassLynxRaw::MassLynxRawScanReader::ReadScan;

			MassLynxRawScanReader(const string & strFullPathName, const string& userLicense) : Waters::Lib::MassLynxRaw::MassLynxRawScanReader(strFullPathName, userLicense) {}
			MassLynxRawScanReader(const MassLynxRawScanReader& massLynxScanReader) : Waters::Lib::MassLynxRaw::MassLynxRawScanReader(massLynxScanReader) {}
			MassLynxRawScanReader(const MassLynxBaseReader& massLynxRawReader) : Waters::Lib::MassLynxRaw::MassLynxRawScanReader(massLynxRawReader) {}
		
			/**
			*  Reads the masses and intensities for the requested function, scan and drift
			*
			*   @param  whichFunction requested function
			*   @param  nWhichScan requested scan
			*   @param  nWhichDrift requested drift
			*   @param [out] vector of mass indeces
			*   @param [out] vector of intensities
			*
			*   @return void
			*/
			void ReadScan(const int& whichFunction, const int& whichScan, const int& whichDrift, vector<int>& masses, vector<float>& intensities)
			{
				// get the data..
				int* pMasses(NULL); float* pIntensities(NULL); int nSize(0);
				CheckReturnCode(readDriftScanIndex(GetRawReader(), whichFunction, whichScan, whichDrift, &pMasses, &pIntensities, &nSize));

				// fill the vector
				ToVector(pMasses, nSize, masses);
				ToVector(pIntensities, nSize, intensities);
			}

			/**
			*  Reads the masses, intensities and flagefor the requested function, scan and drift
			*
			*   @param  whichFunction requested function
			*   @param  nWhichScan requested scan
			*   @param  nWhichDrift requested drift
			*   @param [out] vector of mass indeces
			*   @param [out] vector of intensities
			*   @param [out] vector of flags
			*
			*   @return void
			*/
			void ReadScan(const int& whichFunction, const int& whichScan, const int& whichDrift, vector<int>& masses, vector<float>& intensities, vector<char>& flags)
			{
				// get the data..
				int* pMasses(NULL); float* pIntensities(NULL); char* pFlags(NULL); int nSize(0);
				CheckReturnCode(readDriftScanFlagsIndex(GetRawReader(), whichFunction, whichScan, whichDrift, &pMasses, &pIntensities, &pFlags, &nSize));

				// fill the vector
				ToVector(pMasses, nSize, masses);
				ToVector(pIntensities, nSize, intensities);
				ToVector(pFlags, nSize, flags);
			}

			/**
			*  Reads the masses, intensities and flagefor the requested function, scan and drift
			*
			*   @param  whichFunction requested function
			*   @param  nWhichScan requested scan
			*   @param [out] vector of masses
			*   @param [out] start index
			*
			*   @return void
			*/
			void GetMassScale(const int& whichFunction, const int& whichScan, vector<float>&masses, int& startIndex)
			{
				// get the data
				int nSize(0); float* pMasses(NULL);
				CheckReturnCode(getDriftMassScale(GetRawReader(), whichFunction, whichScan, &pMasses, &nSize, &startIndex));

				// fill the vector
				ToVector(pMasses, nSize, masses);
			}
		};
	}
	/// \endcond
}   // MassLynxRaw
}   // Lib
}   // Waters

