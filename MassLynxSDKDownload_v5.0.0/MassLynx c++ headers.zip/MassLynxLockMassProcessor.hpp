//-----------------------------------------------------------------------------------------------------
// FILE:			MassLynxLockmassProcessor.h
// DATE:			July 2018
// COPYRIGHT(C):	Waters Corporation
//
//-----------------------------------------------------------------------------------------------------
#pragma once

#include "MassLynxRawBase.hpp"
#include "MassLynxParameters.hpp"

namespace Waters
{
namespace Lib
{
namespace MassLynxRaw
{
	/**
	* Applies post acquisition lock mass correction to MassLynx data
	*
	* Lock mass correction can only be applied under certain conditions, data that has been lock mass corrected during acqusition can not be changed. To prevent unnecessary recalculation, comparison between the supplied parameters and the existing lock mass values is made. If these values are different then lock mass correction will be applied. If the 'force' parameter is set to true then lock mass correction will always be applied.
	*
	* If the lock mass algorithm has changed this will also force a recalculation of the lock mass correction.
	*
	* If an error is encountered then an exception will be throw, see exception codes and messages.
	*/

	class MassLynxLockMassProcessor : public MassLynxBaseProcessor
	{
	public:
		MassLynxLockMassProcessor() : MassLynxBaseProcessor(MassLynxBaseType::LOCKMASS) {}

		/**
		*   Removes post acquisition lock mass correction.
		*
		*   @return void
		*/
		void RemoveLockMassCorrection()
		{
			CheckReturnCode(removeLockMassCorrection(GetProcessor()));
		}

		/**
		*   Determines if the raw data has post acquisition lock mass correction applied.
		*
		*   @return false if post acqustion lock mass correction is not applied.
		*/
		bool IsLockMassCorrected() const
		{
			int isCorrected(0);
			CheckReturnCode(LMP_isLockMassCorrected(GetProcessor(), &isCorrected));
			return isCorrected;
		}

		/**
		*   Determines if post acquisition lock mass correction can be applied.
		*
		*   @return false if the raw data can not be lock mass corrected.
		*/
		bool CanLockMassCorrect() const
		{
			int canCorrect(0);
			CheckReturnCode(LMP_canLockMassCorrect(GetProcessor(), &canCorrect));
			return canCorrect;
		}

		/**
		*   Returns the currenty applied lock mass parameters
		*
		*   @return MassLynxParameters
		*	Key	Description
		*	LockMassParameter::MASS			Value of the applied lock mass
		*	LockMassParameter::TOLERANCE	Tolerance applied to the given lock mass used to find lock mass in data
		*/
		MassLynxParameters GetLockMassValue() const
		{
			MassLynxParameters parameters;
			CheckReturnCode(getLockMassValuesParams(GetProcessor(), parameters.GetParameters()));
			return parameters;
		}

		/**
		*   Returns the currenty applied lockmass correction gain for a requested retention time
		*
		*   @param retentionTime
		*
		*   @return gain lock mass gain
		*/
		float GetLockMassCorrection(const float& retentionTime) const
		{
			float gain(0.0f);
			CheckReturnCode(getLockMassCorrection(GetProcessor(), retentionTime, &gain));
			return gain;
		}

		/**
		*   Returns the currenty applied lockmass correction gain for a requested retention time
		*
		*   Exception will not be thrown, use GetLastError to retrieve error code
		*
		*   @param retentionTime
		*   @param [out] gain
		*
		*   @return true if successful
		*/

		bool TryGetLockMassCorrection(const float& retentionTime, float& gain) const
		{
			return CheckReturnCode(getLockMassCorrection(GetProcessor(), retentionTime, &gain), false);
		}

		/**
		*   Sets the parameters into the lock mass processor. 
		*	Parameters are supplied in a key value pair in the MassLynxParameter class
		*
		*	Key	Description
		*	LockMassParameter::MASS			Value of the lock mass
		*	LockMassParameter::TOLERANCE	Tolerance applied to the given lock mass used to find lock mass in data
		*	LockMassParameter::FORCE		Boolean value used to force the lock mass
		*
		*   @param  lockMassParameters 
		*
		*   @return void
		*/
		void SetParameters(const MassLynxParameters& lockMassParameters)
		{
			CheckReturnCode(setLockMassParameters(GetProcessor(), lockMassParameters.GetParameters()));
		}

		/**
		*   Gets the parameters set in the lock mass processor.
		*
		*   @return MassLynxParameters - LockMassParameterclass key / value pairs
		*/
		MassLynxParameters GetParameters() const
		{
			MassLynxParameters parameters;
			CheckReturnCode(getLockMassParameters(GetProcessor(), parameters.GetParameters()));
			return parameters;
		}

		/**
		*  Performs lock mass correction with the supplied parameters
		*
		*   @return bool true if sucessfully lock mass correction is successful
		*/
		bool LockMassCorrect(const MassLynxParameters& lockMassParameters)
		{
			SetParameters(lockMassParameters);
			return LockMassCorrect();
		}

		/**
		*  Performs lock mass correction using set parameters
		*  Use GetParameters() to return the processing parameters
		*
		*   @return bool true if lock mass correction is successful
		*/
		bool LockMassCorrect()
		{
			bool bCorrected(false);
			CheckReturnCode(lockMassCorrect(GetProcessor(), &bCorrected));
			return bCorrected;
		}

		/**
		*  Returns the combined and centrioded spectrum of all lock mass scans
		*  Can be used to identify the lock mass
		*
		*   @param [out] masses vector of masses
		*   @param [out] intensities vector of intensities
		*
		*   @return void
		*/
		void GetCandidates(vector<float>& masses, vector<float>& intensities)
		{
			// get the data..
			float* pMasses(NULL); float* pIntensities(NULL); int nSize(0);
			CheckReturnCode(getLockMassCandidates(GetProcessor(), &pMasses, &pIntensities, &nSize));

			// fill the vector and deallocate the memory
			ToVector(pMasses, nSize, masses, true);
			ToVector(pIntensities, nSize, intensities, true);
		}

		/**
		*  Attempts to automatically apply lock mass correcion using known lock mass compounds
		*  @param force the data to be lockmass corrected, will overwrite any previous lockmass correction
		* 
		*  @return bool true if lock mass correction is successful
		*/
		bool AutoLockMassCorrect(const bool& force)
		{
			bool applied(false);
			CheckReturnCode(autoLockMassCorrect(GetProcessor(), force, &applied));
			return applied;
		}

		/**
		*  Attempts to automatically apply lock mass correcion using known lock mass compounds
		*  @param force the data to be lockmass corrected, will overwrite any previous lockmass correction
		*  @param [out] applied true if lock mass correction is successful
		* 
		*  Exception will not be thrown, use GetLastError to retrieve error code
		* 
		*  @return bool true if lock mass correction is successful
		*/
		bool TryAutoLockMassCorrect(const bool& force, bool& applied)
		{
			return CheckReturnCode(autoLockMassCorrect(GetProcessor(), force, &applied), false);
		}
	};
}   // MassLynxRaw
}   // Lib
}   // Waters
